/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
static volatile uint8_t hp_owns_usb;
static void hp_tick(void);
static int hp_sysex(const uint8_t *,uint32_t);
#define FELUCCA_UAC 0
#define STORE_MAGIC 0x31504855u
#define APP_NAME "USB HOST PROBE"
#define APP_SYSEX hp_sysex
#include "run_identity.h"
#include "platform.c"
#include "probe_core.h"
#ifndef DINGHY_HOST
#include "probe_usb.h"
#else
static uint8_t hp_running;
static void hp_tick(void) {}
static void hp_host_start(void) {hp_v[H_STATE]=HP_FAILED;hp_v[H_REASON]=HP_IO;}
static void hp_host_stop(void) {hp_owns_usb=0;}
#endif
#include "probe_wire.h"
static void app_audio(int32_t *out,uint32_t n) {(void)out;(void)n;}
static const char *const hp_states[]={"DEVICE / NOT ARMED","ARMED / PRESS PLAY","DISCOVERING USB","RUNNING","BUS TEST COMPLETE","TEST FAILED","STOPPED"};
static const char *const hp_reasons[]={"", "NEED 2 IN + 1 OUT", "REGISTER TIMEOUT", "FRAME DEADLINE", "USB TRANSFER ERROR", "NO USB FRAME CLOCK", "BUFFER DRIFT/NO AUDIO", "ARM ON COMPUTER", "DEVICE/FORMAT SETUP", "INCOMPLETE RUN"};
static void hp_text(uint32_t y,const char *text) {draw_text_box(4,y,232,&FONT_S,text,C_WHITE,0);}
static void hp_number(uint32_t y,const char *name,uint32_t value)
{
    char line[32],digits[12];uint32_t n=0,j=0;
    while(*name && n<18)line[n++]=*name++;line[n++]=' ';
    do {digits[j++]=(char)('0'+value%10);value/=10;}while(value);
    while(j)line[n++]=digits[--j];line[n]=0;hp_text(y,line);
}
static void hp_draw(void)
{
    uint32_t state=hp_v[H_STATE];if(state>HP_STOPPED)state=HP_FAILED;
    lcd_fill(0,0,240,240,C_BLACK);
    hp_text(4,"USB HOST PROBE R1");hp_text(30,hp_states[state]);
    if(state==HP_IDLE) {hp_text(62,"ARM VIA COMPUTER MIDI");hp_text(88,"THEN MOVE USB TO HUB");}
    else if(state==HP_ARMED) {hp_number(62,"RATE",hp_v[H_RATE]);hp_number(88,"SECONDS",hp_v[H_DURATION]/1000);hp_text(114,"POWERED HUB REQUIRED");}
    else {
        hp_number(58,"IN A",hp_v[H_A_PACKETS]);hp_number(82,"IN B",hp_v[H_B_PACKETS]);
        hp_number(106,"OUT",hp_v[H_OUT_PACKETS]);hp_number(130,"SECONDS",hp_v[H_ELAPSED]/1000);
        hp_text(154,hp_reasons[hp_v[H_REASON]<=HP_INCOMPLETE?hp_v[H_REASON]:HP_IO]);
        if(!hp_owns_usb)hp_text(177,"RECONNECT PC / FETCH");
    }
    /* All 12 physical menu positions remain present; unused positions are blank. */
    for(uint32_t i=0;i<12;i++) {
        uint32_t x=(i%6)*40,y=204+(i/6)*18;const char *label="";
        if(i==10)label=hp_owns_usb?"STOP":hp_v[H_STATE]==HP_ARMED?"PLAY":"";
        draw_text_box(x,y,40,&FONT_S,label,C_WHITE,1);
    }
}
static void app_main(void)
{
    uint32_t draw=0;palette_set(4);
    hp_v[H_MAGIC]=0x31504855u;hp_v[H_BUILD]=HP_BUILD_TAG;hp_v[H_STATE]=HP_IDLE;
    for(;;) {
        uint32_t released,pressed;platform_poll();pressed=fm1_input_edges(&released);(void)released;
        if(pressed&(1u<<BTN_PLAY)) {
            if(hp_owns_usb) {hp_host_stop();hp_freeze();}
            else if(hp_v[H_STATE]==HP_ARMED) {
                hp_v[H_STATE]=HP_ENUM;hp_draw();hp_host_start();
            }
            draw=0;
        }
        if(hp_owns_usb && !hp_running && hp_v[H_STATE]!=HP_ENUM) {hp_host_stop();hp_freeze();draw=0;}
        if(!draw || fm1_ms-draw>=500) {hp_draw();draw=fm1_ms?fm1_ms:1;}
    }
}
