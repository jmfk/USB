#pragma once
#define HP_BUILD_TAG 1604105024u
#define HP_LABEL "R12"
