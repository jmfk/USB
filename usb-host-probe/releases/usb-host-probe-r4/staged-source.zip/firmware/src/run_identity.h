#pragma once
#define HP_BUILD_TAG 736471641u
#define HP_LABEL "R4"
