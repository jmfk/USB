#pragma once
#define HP_BUILD_TAG 1675001374u
#define HP_LABEL "R16"
